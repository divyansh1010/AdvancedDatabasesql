﻿namespace FinalProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehiclesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toVehiclesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toMakeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toModelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.VehicleTableView = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.VehicleAddView = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.YearText = new System.Windows.Forms.TextBox();
            this.SoldText = new System.Windows.Forms.TextBox();
            this.priceText = new System.Windows.Forms.TextBox();
            this.modelCombo = new System.Windows.Forms.ComboBox();
            this.makeCombo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.MakeAddView = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.makingText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ModelAddView = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.modelSave = new System.Windows.Forms.Button();
            this.vehicleTypeCombo = new System.Windows.Forms.ComboBox();
            this.colorText = new System.Windows.Forms.TextBox();
            this.DoorText = new System.Windows.Forms.TextBox();
            this.engineText = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.TypeAddView = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.vehicleTypeText = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Home = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.databaseDataSet = new FinalProject.DatabaseDataSet();
            this.makeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.makeTableAdapter = new FinalProject.DatabaseDataSetTableAdapters.MakeTableAdapter();
            this.databaseDataSet2 = new FinalProject.DatabaseDataSet2();
            this.vehicleTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vehicleTypeTableAdapter = new FinalProject.DatabaseDataSet2TableAdapters.VehicleTypeTableAdapter();
            this.menuStrip1.SuspendLayout();
            this.VehicleTableView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.VehicleAddView.SuspendLayout();
            this.MakeAddView.SuspendLayout();
            this.ModelAddView.SuspendLayout();
            this.TypeAddView.SuspendLayout();
            this.Home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.makeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehicleTypeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.addToolStripMenuItem,
            this.homeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(487, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vehiclesToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // vehiclesToolStripMenuItem
            // 
            this.vehiclesToolStripMenuItem.Name = "vehiclesToolStripMenuItem";
            this.vehiclesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.vehiclesToolStripMenuItem.Text = "Vehicles";
            this.vehiclesToolStripMenuItem.Click += new System.EventHandler(this.vehiclesToolStripMenuItem_Click);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toVehiclesToolStripMenuItem,
            this.toMakeToolStripMenuItem,
            this.toModelToolStripMenuItem,
            this.toTypeToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.addToolStripMenuItem.Text = " Add Data";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // toVehiclesToolStripMenuItem
            // 
            this.toVehiclesToolStripMenuItem.Name = "toVehiclesToolStripMenuItem";
            this.toVehiclesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.toVehiclesToolStripMenuItem.Text = "To Vehicles";
            this.toVehiclesToolStripMenuItem.Click += new System.EventHandler(this.toVehiclesToolStripMenuItem_Click);
            // 
            // toMakeToolStripMenuItem
            // 
            this.toMakeToolStripMenuItem.Name = "toMakeToolStripMenuItem";
            this.toMakeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.toMakeToolStripMenuItem.Text = "To Make";
            this.toMakeToolStripMenuItem.Click += new System.EventHandler(this.toMakeToolStripMenuItem_Click);
            // 
            // toModelToolStripMenuItem
            // 
            this.toModelToolStripMenuItem.Name = "toModelToolStripMenuItem";
            this.toModelToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.toModelToolStripMenuItem.Text = "To Model";
            this.toModelToolStripMenuItem.Click += new System.EventHandler(this.toModelToolStripMenuItem_Click);
            // 
            // toTypeToolStripMenuItem
            // 
            this.toTypeToolStripMenuItem.Name = "toTypeToolStripMenuItem";
            this.toTypeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.toTypeToolStripMenuItem.Text = "To Type";
            this.toTypeToolStripMenuItem.Click += new System.EventHandler(this.toTypeToolStripMenuItem_Click);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // VehicleTableView
            // 
            this.VehicleTableView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("VehicleTableView.BackgroundImage")));
            this.VehicleTableView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.VehicleTableView.Controls.Add(this.dataGridView1);
            this.VehicleTableView.Controls.Add(this.button8);
            this.VehicleTableView.Controls.Add(this.button7);
            this.VehicleTableView.Controls.Add(this.button6);
            this.VehicleTableView.Controls.Add(this.button5);
            this.VehicleTableView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VehicleTableView.Location = new System.Drawing.Point(0, 24);
            this.VehicleTableView.Name = "VehicleTableView";
            this.VehicleTableView.Size = new System.Drawing.Size(487, 299);
            this.VehicleTableView.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 15);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(423, 196);
            this.dataGridView1.TabIndex = 4;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(300, 255);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(138, 23);
            this.button8.TabIndex = 3;
            this.button8.Text = "View Summary";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(300, 217);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(138, 23);
            this.button7.TabIndex = 2;
            this.button7.Text = "View Available Vehicles";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(49, 255);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(112, 23);
            this.button6.TabIndex = 1;
            this.button6.Text = "View Sold Vehicles";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(49, 217);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "View Full Table";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // VehicleAddView
            // 
            this.VehicleAddView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("VehicleAddView.BackgroundImage")));
            this.VehicleAddView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.VehicleAddView.Controls.Add(this.label7);
            this.VehicleAddView.Controls.Add(this.label6);
            this.VehicleAddView.Controls.Add(this.label5);
            this.VehicleAddView.Controls.Add(this.label4);
            this.VehicleAddView.Controls.Add(this.label3);
            this.VehicleAddView.Controls.Add(this.button1);
            this.VehicleAddView.Controls.Add(this.YearText);
            this.VehicleAddView.Controls.Add(this.SoldText);
            this.VehicleAddView.Controls.Add(this.priceText);
            this.VehicleAddView.Controls.Add(this.modelCombo);
            this.VehicleAddView.Controls.Add(this.makeCombo);
            this.VehicleAddView.Controls.Add(this.label2);
            this.VehicleAddView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VehicleAddView.Location = new System.Drawing.Point(0, 24);
            this.VehicleAddView.Name = "VehicleAddView";
            this.VehicleAddView.Size = new System.Drawing.Size(487, 299);
            this.VehicleAddView.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(256, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Sold Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(256, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(29, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Year";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(29, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Model";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(29, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Make";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Location = new System.Drawing.Point(363, 126);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // YearText
            // 
            this.YearText.Location = new System.Drawing.Point(86, 111);
            this.YearText.Name = "YearText";
            this.YearText.Size = new System.Drawing.Size(121, 20);
            this.YearText.TabIndex = 6;
            // 
            // SoldText
            // 
            this.SoldText.Location = new System.Drawing.Point(317, 75);
            this.SoldText.Name = "SoldText";
            this.SoldText.Size = new System.Drawing.Size(121, 20);
            this.SoldText.TabIndex = 5;
            // 
            // priceText
            // 
            this.priceText.Location = new System.Drawing.Point(317, 39);
            this.priceText.Name = "priceText";
            this.priceText.Size = new System.Drawing.Size(121, 20);
            this.priceText.TabIndex = 4;
            // 
            // modelCombo
            // 
            this.modelCombo.DataSource = this.vehicleTypeBindingSource;
            this.modelCombo.DisplayMember = "Name";
            this.modelCombo.FormattingEnabled = true;
            this.modelCombo.Location = new System.Drawing.Point(86, 74);
            this.modelCombo.Name = "modelCombo";
            this.modelCombo.Size = new System.Drawing.Size(121, 21);
            this.modelCombo.TabIndex = 3;
            this.modelCombo.ValueMember = "VehicleTypeId";
            this.modelCombo.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // makeCombo
            // 
            this.makeCombo.DataSource = this.makeBindingSource;
            this.makeCombo.DisplayMember = "Name";
            this.makeCombo.FormattingEnabled = true;
            this.makeCombo.Location = new System.Drawing.Point(86, 38);
            this.makeCombo.Name = "makeCombo";
            this.makeCombo.Size = new System.Drawing.Size(121, 21);
            this.makeCombo.TabIndex = 2;
            this.makeCombo.ValueMember = "MakeId";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkCyan;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(183, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Add New Vehicle";
            // 
            // MakeAddView
            // 
            this.MakeAddView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MakeAddView.BackgroundImage")));
            this.MakeAddView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MakeAddView.Controls.Add(this.button2);
            this.MakeAddView.Controls.Add(this.label9);
            this.MakeAddView.Controls.Add(this.makingText);
            this.MakeAddView.Controls.Add(this.label8);
            this.MakeAddView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MakeAddView.Location = new System.Drawing.Point(0, 24);
            this.MakeAddView.Name = "MakeAddView";
            this.MakeAddView.Size = new System.Drawing.Size(487, 299);
            this.MakeAddView.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(278, 82);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(46, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Make";
            // 
            // makingText
            // 
            this.makingText.Location = new System.Drawing.Point(95, 85);
            this.makingText.Name = "makingText";
            this.makingText.Size = new System.Drawing.Size(155, 20);
            this.makingText.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(131, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(222, 31);
            this.label8.TabIndex = 0;
            this.label8.Text = "Register your car";
            // 
            // ModelAddView
            // 
            this.ModelAddView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ModelAddView.BackgroundImage")));
            this.ModelAddView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ModelAddView.Controls.Add(this.label14);
            this.ModelAddView.Controls.Add(this.label13);
            this.ModelAddView.Controls.Add(this.label12);
            this.ModelAddView.Controls.Add(this.label11);
            this.ModelAddView.Controls.Add(this.modelSave);
            this.ModelAddView.Controls.Add(this.vehicleTypeCombo);
            this.ModelAddView.Controls.Add(this.colorText);
            this.ModelAddView.Controls.Add(this.DoorText);
            this.ModelAddView.Controls.Add(this.engineText);
            this.ModelAddView.Controls.Add(this.label10);
            this.ModelAddView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ModelAddView.Location = new System.Drawing.Point(0, 24);
            this.ModelAddView.Name = "ModelAddView";
            this.ModelAddView.Size = new System.Drawing.Size(487, 299);
            this.ModelAddView.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(56, 177);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Vehicle Type";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(94, 141);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Color";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(58, 105);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "No. of Doors";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(58, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Engine Type";
            // 
            // modelSave
            // 
            this.modelSave.Location = new System.Drawing.Point(131, 217);
            this.modelSave.Name = "modelSave";
            this.modelSave.Size = new System.Drawing.Size(75, 23);
            this.modelSave.TabIndex = 5;
            this.modelSave.Text = "Save";
            this.modelSave.UseVisualStyleBackColor = true;
            this.modelSave.Click += new System.EventHandler(this.modelSave_Click);
            // 
            // vehicleTypeCombo
            // 
            this.vehicleTypeCombo.DataSource = this.vehicleTypeBindingSource;
            this.vehicleTypeCombo.DisplayMember = "Name";
            this.vehicleTypeCombo.FormattingEnabled = true;
            this.vehicleTypeCombo.Location = new System.Drawing.Point(131, 174);
            this.vehicleTypeCombo.Name = "vehicleTypeCombo";
            this.vehicleTypeCombo.Size = new System.Drawing.Size(107, 21);
            this.vehicleTypeCombo.TabIndex = 4;
            this.vehicleTypeCombo.ValueMember = "VehicleTypeId";
            // 
            // colorText
            // 
            this.colorText.Location = new System.Drawing.Point(131, 138);
            this.colorText.Name = "colorText";
            this.colorText.Size = new System.Drawing.Size(131, 20);
            this.colorText.TabIndex = 3;
            // 
            // DoorText
            // 
            this.DoorText.Location = new System.Drawing.Point(131, 102);
            this.DoorText.Name = "DoorText";
            this.DoorText.Size = new System.Drawing.Size(131, 20);
            this.DoorText.TabIndex = 2;
            // 
            // engineText
            // 
            this.engineText.Location = new System.Drawing.Point(131, 65);
            this.engineText.Name = "engineText";
            this.engineText.Size = new System.Drawing.Size(131, 20);
            this.engineText.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(159, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 27);
            this.label10.TabIndex = 0;
            this.label10.Text = "Select the Model";
            // 
            // TypeAddView
            // 
            this.TypeAddView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TypeAddView.BackgroundImage")));
            this.TypeAddView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TypeAddView.Controls.Add(this.button4);
            this.TypeAddView.Controls.Add(this.vehicleTypeText);
            this.TypeAddView.Controls.Add(this.label16);
            this.TypeAddView.Controls.Add(this.label15);
            this.TypeAddView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeAddView.Location = new System.Drawing.Point(0, 24);
            this.TypeAddView.Name = "TypeAddView";
            this.TypeAddView.Size = new System.Drawing.Size(487, 299);
            this.TypeAddView.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(86, 107);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // vehicleTypeText
            // 
            this.vehicleTypeText.Location = new System.Drawing.Point(86, 75);
            this.vehicleTypeText.Name = "vehicleTypeText";
            this.vehicleTypeText.Size = new System.Drawing.Size(138, 20);
            this.vehicleTypeText.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(12, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Vehicle Type";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.Control;
            this.label15.Location = new System.Drawing.Point(131, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(228, 27);
            this.label15.TabIndex = 0;
            this.label15.Text = "Select Vehicle Type";
            // 
            // Home
            // 
            this.Home.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Home.BackgroundImage")));
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Controls.Add(this.label1);
            this.Home.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Home.Location = new System.Drawing.Point(0, 24);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(487, 299);
            this.Home.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(329, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome to Wolf Spirit Car Lot";
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "DatabaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // makeBindingSource
            // 
            this.makeBindingSource.DataMember = "Make";
            this.makeBindingSource.DataSource = this.databaseDataSet;
            // 
            // makeTableAdapter
            // 
            this.makeTableAdapter.ClearBeforeFill = true;
            // 
            // databaseDataSet2
            // 
            this.databaseDataSet2.DataSetName = "DatabaseDataSet2";
            this.databaseDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vehicleTypeBindingSource
            // 
            this.vehicleTypeBindingSource.DataMember = "VehicleType";
            this.vehicleTypeBindingSource.DataSource = this.databaseDataSet2;
            // 
            // vehicleTypeTableAdapter
            // 
            this.vehicleTypeTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 323);
            this.Controls.Add(this.TypeAddView);
            this.Controls.Add(this.MakeAddView);
            this.Controls.Add(this.ModelAddView);
            this.Controls.Add(this.VehicleAddView);
            this.Controls.Add(this.VehicleTableView);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.VehicleTableView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.VehicleAddView.ResumeLayout(false);
            this.VehicleAddView.PerformLayout();
            this.MakeAddView.ResumeLayout(false);
            this.MakeAddView.PerformLayout();
            this.ModelAddView.ResumeLayout(false);
            this.ModelAddView.PerformLayout();
            this.TypeAddView.ResumeLayout(false);
            this.TypeAddView.PerformLayout();
            this.Home.ResumeLayout(false);
            this.Home.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.makeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vehicleTypeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehiclesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.Panel VehicleTableView;
        private System.Windows.Forms.ToolStripMenuItem toVehiclesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toMakeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toModelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toTypeToolStripMenuItem;
        private System.Windows.Forms.Panel VehicleAddView;
        private System.Windows.Forms.Panel MakeAddView;
        private System.Windows.Forms.Panel ModelAddView;
        private System.Windows.Forms.Panel TypeAddView;
        private System.Windows.Forms.Panel Home;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox YearText;
        private System.Windows.Forms.TextBox SoldText;
        private System.Windows.Forms.TextBox priceText;
        private System.Windows.Forms.ComboBox modelCombo;
        private System.Windows.Forms.ComboBox makeCombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox makingText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button modelSave;
        private System.Windows.Forms.ComboBox vehicleTypeCombo;
        private System.Windows.Forms.TextBox colorText;
        private System.Windows.Forms.TextBox DoorText;
        private System.Windows.Forms.TextBox engineText;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox vehicleTypeText;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DatabaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource makeBindingSource;
        private DatabaseDataSetTableAdapters.MakeTableAdapter makeTableAdapter;
        private DatabaseDataSet2 databaseDataSet2;
        private System.Windows.Forms.BindingSource vehicleTypeBindingSource;
        private DatabaseDataSet2TableAdapters.VehicleTypeTableAdapter vehicleTypeTableAdapter;
    }
}

