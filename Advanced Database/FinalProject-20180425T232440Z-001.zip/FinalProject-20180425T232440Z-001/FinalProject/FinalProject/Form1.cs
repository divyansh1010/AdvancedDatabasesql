﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet2.VehicleType' table. You can move, or remove it, as needed.
            this.vehicleTypeTableAdapter.Fill(this.databaseDataSet2.VehicleType);
            // TODO: This line of code loads data into the 'databaseDataSet.Make' table. You can move, or remove it, as needed.
            this.makeTableAdapter.Fill(this.databaseDataSet.Make);

            Show_Home();

        }

        private void FillDataVehicleTable()
        {
            dataGridView1.AutoGenerateColumns = true;
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            SqlDataAdapter adp = new SqlDataAdapter("SELECT distinct Make.Name as 'Model' , VehicleType.Name as 'Make' , Year, Price, SoldDate  " +
                                                    "FROM  Vehicle, Make, Model, VehicleType where Vehicle.MakeId = Make.MakeId and " +
                                                    "Vehicle.ModelId = Model.ModelId and " +
                                                    "Model.VehicleTypeId = VehicleType.VehicleTypeId " +
                                                    " ", dbConnection);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;

            dbConnection.Close();
        }

        

        private void Show_VehicleTable()
        {
            VehicleTableView.Visible = true;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }
        private void Show_MakeTable()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }

        private void Show_ModelTable()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }
        private void Show_TypeTable()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }

        private void Show_VehicleAdd()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = true;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }

        private void Show_MakeAdd()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = true;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }

        private void Show_ModelAdd()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = true;
            TypeAddView.Visible = false;

            Home.Visible = false;
        }

        private void Show_TypeAdd()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = true;

            Home.Visible = false;
        }
        private void Show_Home()
        {
            VehicleTableView.Visible = false;
            VehicleAddView.Visible = false;
            MakeAddView.Visible = false;
            ModelAddView.Visible = false;
            TypeAddView.Visible = false;

            Home.Visible = true ;
        }

            private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void vehiclesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_VehicleTable();
        }

        private void makeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_MakeTable();
        }

        private void modelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_ModelTable();
        }

        private void typeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_TypeTable();
        }

        private void toVehiclesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_VehicleAdd();
        }

        private void toMakeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_MakeAdd();
        }

        private void toModelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_ModelAdd();
        }

        private void toTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_TypeAdd();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Show_Home();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            ViewAvailableVehicles();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FillDataVehicleTable();
        }

        private void ViewAvailableVehicles()
        {
            dataGridView1.AutoGenerateColumns = true;
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            SqlDataAdapter adp = new SqlDataAdapter("SELECT distinct Make.Name as 'Model' , VehicleType.Name as 'Make' , Year, Price, SoldDate  " +
                                                    "FROM  Vehicle, Make, Model, VehicleType where Vehicle.MakeId = Make.MakeId and " +
                                                    "Vehicle.ModelId = Model.ModelId and " +
                                                    "Model.VehicleTypeId = VehicleType.VehicleTypeId and" +
                                                    " Price IS NULL ", dbConnection);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;

            dbConnection.Close();
        }

        private void ViewSoldVehicles()
        {
            dataGridView1.AutoGenerateColumns = true;
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            SqlDataAdapter adp = new SqlDataAdapter("SELECT distinct Make.Name as 'Model' , VehicleType.Name as 'Make' , Year, Price, SoldDate  " +
                                                    "FROM  Vehicle, Make, Model, VehicleType where Vehicle.MakeId = Make.MakeId and " +
                                                    "Vehicle.ModelId = Model.ModelId and " +
                                                    "Model.VehicleTypeId = VehicleType.VehicleTypeId and" +
                                                    " Price IS NOT NULL ", dbConnection);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;

            dbConnection.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ViewSoldVehicles();
        }

        private void ViewSummary()
        {
            dataGridView1.AutoGenerateColumns = true;
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();
            SqlDataAdapter adp = new SqlDataAdapter("SELECT distinct count(Price) as 'Vehicle Sold', Sum(Price) as 'Total Income', AVG(Price) as 'Average Price'  " +
                                                    "FROM  Vehicle where Price is not null " +
                                                    "UNION " +
                                                    "SELECT distinct count(Price) as 'Vehicle Not Sold', Sum(Price) as 'Total Income', AVG(Price) as 'Average Price'  " +
                                                    "FROM  Vehicle where Price is null ", dbConnection);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;

            dbConnection.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ViewSummary();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            save_Vehicle();
        }

        private void save_Vehicle()
        {
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            string query = "INSERT INTO Vehicle (MakeId,ModelId,Price,Year,SoldDate) VALUES (@M,@mk,@P,@Y,@S)";

            SqlCommand command = new SqlCommand(query, dbConnection);


            float price = float.Parse(priceText.Text);
            string year = YearText.Text;
            string sold = SoldText.Text;
            int make = Int32.Parse(makeCombo.SelectedValue.ToString());
            int model = Int32.Parse(modelCombo.SelectedValue.ToString());

            command.Parameters.Add(new SqlParameter("M",make ));
            command.Parameters.Add(new SqlParameter("mk",model ));
            command.Parameters.Add(new SqlParameter("P",price));
            command.Parameters.Add(new SqlParameter("Y",year ));
            command.Parameters.Add(new SqlParameter("S", sold));

            MessageBox.Show("Saved");
            priceText.Text = "";
            YearText.Text = "";
            SoldText.Text = "";

            command.ExecuteNonQuery();

            dbConnection.Close();
        }

        private void modelSave_Click(object sender, EventArgs e)
        {
            saveModel();
        }

        private void saveModel()
        {
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            string query = "INSERT INTO Model (EngineSize,Doors,Color,VehicleTypeId) VALUES (@E,@D,@C,@V)";

            SqlCommand command = new SqlCommand(query, dbConnection);

            string EngineSize = engineText.Text;
            string Doors = DoorText.Text;
            string color = colorText.Text;
            int type = Int32.Parse(vehicleTypeCombo.SelectedValue.ToString());

            command.Parameters.Add(new SqlParameter("E", EngineSize));
            command.Parameters.Add(new SqlParameter("D", Doors));
            command.Parameters.Add(new SqlParameter("C", color));
            command.Parameters.Add(new SqlParameter("V", type));

            MessageBox.Show("Saved");
            engineText.Text = "";
            DoorText.Text = "";
            colorText.Text = "";

            command.ExecuteNonQuery();

            dbConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveMake();
        }
        private void saveMake()
        {
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            string query = "INSERT INTO Make (Name) VALUES (@N)";

            SqlCommand command = new SqlCommand(query, dbConnection);

            string name = makingText.Text;

            command.Parameters.Add(new SqlParameter("N", name));

            MessageBox.Show("Saved");
            makingText.Text = "";

            command.ExecuteNonQuery();

            dbConnection.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            saveType();
        }
        private void saveType()
        {
            SqlConnection dbConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\comp\FinalProject-20180425T232440Z-001\FinalProject\FinalProject\Database.mdf;Integrated Security=True");
            dbConnection.Open();

            string query = "INSERT INTO VehicleType (Name) VALUES (@N)";

            SqlCommand command = new SqlCommand(query, dbConnection);

            string name = vehicleTypeText.Text;

            command.Parameters.Add(new SqlParameter("N", name));

            MessageBox.Show("Saved");
            vehicleTypeText.Text = "";

            command.ExecuteNonQuery();

            dbConnection.Close();
        }

    }
}
