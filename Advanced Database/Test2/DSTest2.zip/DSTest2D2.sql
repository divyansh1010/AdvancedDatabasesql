SELECT '';
SELECT '' AS '*** Question D2 [8 Marks] ***';
